dep = None
def setup(in_dep):
    global dep
    assert(hasattr(in_dep, "registerRemote"))
    assert(hasattr(in_dep, "put"))
    assert(hasattr(in_dep, "get"))
    dep = in_dep

registerRemote = dep.registerRemote
put = dep.put
get = dep.get